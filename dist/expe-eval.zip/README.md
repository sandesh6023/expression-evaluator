Expression Evaluator
====================

expr_eval.sh "2 + 3" will return "2 + 3"

The actual product development starts.